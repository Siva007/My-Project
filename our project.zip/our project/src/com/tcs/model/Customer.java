package com.tcs.model;

public class Customer
{
   private String customerName;
   private String password;
  

private String address;
   private String dateOfBirth;
   private String gender;
   private String phoneNumber;
   private String emailId;
   private int AcknowlegmentId;
   private int CustomerId;
   private String idproof;
   private String image;
   private String regDate;
   public String getAddressProof() {
	return addressProof;
}
public void setAddressProof(String addressProof) {
	this.addressProof = addressProof;
}
public String getAddressImage() {
	return addressImage;
}
public void setAddressImage(String addressImage) {
	this.addressImage = addressImage;
}
private String addressProof;
   private String addressImage;
   
   
   
   
public String getRegDate() {
	return regDate;
}
public void setRegDate(String regDate) {
	this.regDate = regDate;
}
public String getImage() {
	return image;
}
public void setImage(String image) {
	this.image = image;
}
public String getIdproof() {
	return idproof;
}
public void setIdproof(String idproof) {
	this.idproof = idproof;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getDateOfBirth() {
	return dateOfBirth;
}
public void setDateOfBirth(String dateOfBirth) {
	this.dateOfBirth = dateOfBirth;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}

public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public String getPhoneNumber() {
	return phoneNumber;
}
public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
}
public int getAcknowlegmentId() {
	return AcknowlegmentId;
}
public void setAcknowlegmentId(int acknowlegmentId) {
	AcknowlegmentId = acknowlegmentId;
}
public int getCustomerId() {
	return CustomerId;
}
public void setCustomerId(int customerId) {
	CustomerId = customerId;
}
   

	
	
	
}
