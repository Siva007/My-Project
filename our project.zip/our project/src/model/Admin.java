package model;

public class Admin {

}
