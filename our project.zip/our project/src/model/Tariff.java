package model;

public class Tariff {

}
