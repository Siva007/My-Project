package model;

public class Login {

}
